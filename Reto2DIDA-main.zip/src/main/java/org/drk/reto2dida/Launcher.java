package org.drk.reto2dida;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(App.class, args);
    }
}
